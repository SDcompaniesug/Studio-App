package com.buildflow;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import com.buildflow.model.BuildRecord;
import com.buildflow.storage.AppStorage;
import com.buildflow.util.Utils;

import java.util.List;

/**
 * Main landing page: shows recent builds, quick actions, and
 * a bottom navigation to other screens.
 */
public class HomeActivity extends AppCompatActivity {

    private static final int REQUEST_PICK_ZIP = 101;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private RecyclerView recentRecycler;
    private TextView recentEmpty;
    private View btnBuild;
    private View btnProjects;
    private BottomNavigationView bottomNav;
    private TextView title;

    private AppStorage storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        storage = new AppStorage(this);

        title = findViewById(R.id.toolbarTitle);
        recentRecycler = findViewById(R.id.recentRecycler);
        recentEmpty = findViewById(R.id.recentEmpty);
        btnBuild = findViewById(R.id.btnBuildNow);
        btnProjects = findViewById(R.id.btnSeeProjects);
        bottomNav = findViewById(R.id.bottomNav);
        bottomNav.setSelectedItemId(R.id.nav_home);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_projects) {
                openProjects();
                return false; // stay on Home as the checked tab
            } else if (id == R.id.nav_settings) {
                openSettings();
                return false;
            }
            return true;
        });
        btnBuild.setOnClickListener(v -> {
            Intent i = new Intent(this, BuildActivity.class);
            i.putExtra(BuildActivity.EXTRA_ACTION, "pick_zip");
            startActivityForResult(i, REQUEST_PICK_ZIP);
        });
        btnProjects.setOnClickListener(v -> openProjects());

        recentRecycler.setLayoutManager(new LinearLayoutManager(this));
        refreshRecent();

        // Update setup token state
        updateTokenState();
    }

    private void updateTokenState() {
        TextView tokenStatus = findViewById(R.id.tokenStatus);
        if (tokenStatus != null) {
            if (storage.hasToken()) {
                tokenStatus.setText(R.string.token_set);
                tokenStatus.setTextColor(0xFF2E7D32);
                tokenStatus.setAlpha(1f);
            } else {
                tokenStatus.setText(R.string.token_missing);
                tokenStatus.setTextColor(0xFFD32F2F);
            }
        }
    }

    private void openProjects() {
        startActivity(new Intent(this, ProjectsActivity.class));
    }

    private void openSettings() {
        startActivity(new Intent(this, SettingsActivity.class));
    }

    private void refreshRecent() {
        List<BuildRecord> list = storage.getHistory();
        if (list.isEmpty()) {
            recentEmpty.setVisibility(View.VISIBLE);
            recentRecycler.setVisibility(View.GONE);
        } else {
            recentEmpty.setVisibility(View.GONE);
            recentRecycler.setVisibility(View.VISIBLE);
            recentRecycler.setAdapter(new RecentAdapter(list.subList(0, Math.min(list.size(), 8))));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateTokenState();
        refreshRecent();
    }

    // ----------------------------------------------------------------
    // Internal adapter
    // ----------------------------------------------------------------

    private class RecentAdapter extends RecyclerView.Adapter<RecentAdapter.VH> {
        final List<BuildRecord> items;
        RecentAdapter(List<BuildRecord> items) { this.items = items; }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull android.view.ViewGroup parent, int viewType) {
            View v = getLayoutInflater().inflate(R.layout.item_recent_build, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            BuildRecord r = items.get(position);
            h.name.setText(r.repoName);
            h.branch.setText(r.branch);
            h.when.setText(Utils.formatTime(r.timestamp));
            h.type.setText(r.debugBuild ? R.string.build_type_debug : R.string.build_type_release);
            if (r.status == 1) {
                h.status.setText(R.string.status_success);
                h.status.setTextColor(0xFF2E7D32);
            } else if (r.status == 2) {
                h.status.setText(R.string.status_failed);
                h.status.setTextColor(0xFFD32F2F);
            } else {
                h.status.setText(R.string.status_pending);
                h.status.setTextColor(0xFF1565C0);
            }
            h.itemView.setOnClickListener(v -> {
                Intent i = new Intent(HomeActivity.this, BuildActivity.class);
                i.putExtra(BuildActivity.EXTRA_ACTION, "view");
                i.putExtra(BuildActivity.EXTRA_REPO, r.repoName);
                startActivity(i);
            });
        }

        @Override
        public int getItemCount() { return items.size(); }

        class VH extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            TextView name, branch, when, type, status;
            VH(View v) {
                super(v);
                name = v.findViewById(R.id.itemName);
                branch = v.findViewById(R.id.itemBranch);
                when = v.findViewById(R.id.itemWhen);
                type = v.findViewById(R.id.itemType);
                status = v.findViewById(R.id.itemStatus);
            }
        }
    }
}
