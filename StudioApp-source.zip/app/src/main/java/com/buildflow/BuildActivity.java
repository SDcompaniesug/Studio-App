package com.buildflow;

import android.app.Activity;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.buildflow.api.GitHubApi;
import com.buildflow.model.BuildRecord;
import com.buildflow.storage.AppStorage;
import com.buildflow.util.Utils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Build screen: pick a zip, pick debug/release, tap Build,
 * watch the workflow logs, and download the resulting APK.
 *
 * Also doubles as the "view build" screen for past builds
 * (via EXTRA_REPO + EXTRA_ACTION = "view").
 */
public class BuildActivity extends AppCompatActivity {

    public static final String EXTRA_ACTION = "action";
    public static final String EXTRA_REPO = "repo";
    public static final String ACTION_PICK_ZIP = "pick_zip";
    public static final String ACTION_VIEW = "view";

    private static final int REQUEST_ZIP = 201;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private View progressView;
    private View logsView;
    private View btnPickZip;
    private TextView logText;
    private TextView statusText;
    private Button btnBuild;
    private Button btnDownload;
    private TextView pickedFile;
    private RadioGroup buildTypeGroup;
    private RadioButton rbDebug;
    private RadioButton rbRelease;
    private ImageButton backBtn;
    private TextView title;

    private AppStorage storage;
    private GitHubApi api;

    private File pickedZip;
    private String selectedProjectName;
    private String repoName;
    private BuildRecord activeRecord;
    private long currentRunId = -1;
    private String currentJobId;
    private String lastStepSummary = "";
    private boolean finalLogsRequested = false;
    private String lastLiveLogSnapshot = "";
    private long lastLiveLogFetchAt = 0L;
    private long dispatchStartedAt = 0L;
    private boolean running = false;
    private Runnable pollRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_build);
        storage = new AppStorage(this);
        api = new GitHubApi(this);

        backBtn = findViewById(R.id.backBtn);
        title = findViewById(R.id.buildTitle);
        progressView = findViewById(R.id.progressView);
        logsView = findViewById(R.id.logsView);
        btnPickZip = findViewById(R.id.btnPickZip);
        logText = findViewById(R.id.logText);
        View copyLogs = findViewById(R.id.btnCopyLogs);
        View clearLogs = findViewById(R.id.btnClearLogs);
        if (copyLogs != null) copyLogs.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Build workflow logs", logText.getText()));
            Toast.makeText(this, "Workflow logs copied", Toast.LENGTH_SHORT).show();
        });
        if (clearLogs != null) clearLogs.setOnClickListener(v -> logText.setText(""));
        statusText = findViewById(R.id.statusText);
        btnBuild = findViewById(R.id.btnBuild);
        btnDownload = findViewById(R.id.btnDownload);
        pickedFile = findViewById(R.id.pickedFile);
        buildTypeGroup = findViewById(R.id.buildTypeGroup);
        rbDebug = findViewById(R.id.rbDebug);
        rbRelease = findViewById(R.id.rbRelease);

        backBtn.setOnClickListener(v -> finish());
        btnPickZip.setOnClickListener(v -> pickZip());
        btnBuild.setOnClickListener(v -> startBuild());
        btnBuild.setEnabled(false);
        btnDownload.setOnClickListener(v -> downloadApk());

        Intent intent = getIntent();
        String action = intent != null ? intent.getStringExtra(EXTRA_ACTION) : ACTION_PICK_ZIP;
        if (ACTION_VIEW.equals(action)) {
            String repo = intent.getStringExtra(EXTRA_REPO);
            if (repo != null) {
                repoName = repo;
                showLogsOnly();
            }
        }
    }

    // ----------------------------------------------------------------
    // Zip picker
    // ----------------------------------------------------------------

    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "application/zip", "application/x-zip-compressed", "application/octet-stream"
        });
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQUEST_ZIP);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_ZIP || resultCode != Activity.RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) {
            Toast.makeText(this, R.string.could_not_read_zip, Toast.LENGTH_LONG).show();
            return;
        }
        try {
            int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            if (flags != 0) getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) { }

        File cached = cacheUri(uri);
        if (cached != null && isUsableGradleZip(cached)) {
            pickedZip = cached;
            pickedFile.setText(selectedProjectName + "  ·  " + Utils.formatBytes(cached.length()));
            pickedFile.setVisibility(View.VISIBLE);
            btnBuild.setEnabled(true);
            Toast.makeText(this, "Project ZIP selected. Tap Build to continue.", Toast.LENGTH_SHORT).show();
        } else {
            if (cached != null) cached.delete();
            pickedZip = null;
            btnBuild.setEnabled(false);
            pickedFile.setVisibility(View.GONE);
            Toast.makeText(this, "Could not read a Gradle project ZIP. Select a ZIP containing gradlew and build.gradle.", Toast.LENGTH_LONG).show();
        }
    }

    private String getDisplayName(Uri uri) {
        String name = null;
        try (Cursor cursor = getContentResolver().query(uri,
                new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) { }
        if (name == null || name.trim().isEmpty()) name = uri.getLastPathSegment();
        if (name == null || name.trim().isEmpty()) name = "project.zip";
        return name;
    }

    private File cacheUri(Uri uri) {
        File out = null;
        try {
            selectedProjectName = getDisplayName(uri);
            String safeName = selectedProjectName.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!safeName.toLowerCase(java.util.Locale.US).endsWith(".zip")) safeName += ".zip";
            File dir = new File(getCacheDir(), "uploads");
            if (!dir.exists() && !dir.mkdirs()) return null;
            out = new File(dir, System.currentTimeMillis() + "_" + safeName);
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream stream = new java.io.BufferedOutputStream(new java.io.FileOutputStream(out))) {
                if (in == null) return null;
                byte[] buffer = new byte[16384];
                int count;
                while ((count = in.read(buffer)) != -1) stream.write(buffer, 0, count);
                stream.flush();
            }
            return out;
        } catch (Exception e) {
            if (out != null) out.delete();
            return null;
        }
    }

    private boolean isUsableGradleZip(File file) {
        if (file == null || !file.isFile() || file.length() < 4) return false;
        try (ZipFile zip = new ZipFile(file)) {
            boolean foundGradleFile = false;
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                String name = entries.nextElement().getName();
                if (name.endsWith("gradlew") || name.endsWith("build.gradle")
                        || name.endsWith("build.gradle.kts") || name.endsWith("settings.gradle")
                        || name.endsWith("settings.gradle.kts")) foundGradleFile = true;
            }
            return foundGradleFile;
        } catch (Exception e) {
            return false;
        }
    }

    // ----------------------------------------------------------------
    // Build flow
    // ----------------------------------------------------------------

    private void startBuild() {
        if (running) return;
        if (pickedZip == null) {
            pickZip();
            return;
        }
        if (!storage.hasToken()) {
            Toast.makeText(this, R.string.add_token_first, Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, SettingsActivity.class));
            return;
        }
        if (!Utils.isNetworkAvailable(this)) {
            Toast.makeText(this, R.string.no_network, Toast.LENGTH_LONG).show();
            return;
        }

        running = true;
        btnBuild.setEnabled(false);
        btnBuild.setText(R.string.building);
        btnDownload.setEnabled(false);
        showLogsOnly();
        logText.setText("");
        currentRunId = -1;
        currentJobId = null;
        lastStepSummary = "";
        finalLogsRequested = false;
        dispatchStartedAt = System.currentTimeMillis();
        statusText.setText(R.string.status_uploading);
        appendLog("=== BUILD STARTED ===\n");
        appendLog("Preparing project ZIP and connecting to GitHub...\n");

        new Thread(() -> {
            try {
                // 1. Sanitize name from zip
                String rawName = selectedProjectName == null ? pickedZip.getName() : selectedProjectName;
                rawName = rawName.replaceFirst("(?i)\\.zip$", "");
                repoName = Utils.sanitizeRepoName(rawName);

                appendLog("Repository: " + repoName + "\n");

                // 2. Create the repository
                appendLog("Creating repository (if it does not exist)...\n");
                GitHubApi.CreatedRepo created = api.createRepository(repoName);
                appendLog("Repository ready: " + created.name + "\n");

                // 3. Push files + workflow
                appendLog("Uploading project files + workflow...\n");
                api.pushProjectFiles(repoName, pickedZip, "");
                appendLog("Files uploaded. Dispatching workflow...\n");

                // 4. Dispatch
                boolean debug = rbDebug.isChecked();
                String buildType = debug ? "debug" : "release";
                api.dispatchWorkflow(repoName, buildType);

                activeRecord = new BuildRecord();
                activeRecord.repoName = repoName;
                activeRecord.branch = "main";
                activeRecord.debugBuild = debug;
                activeRecord.timestamp = System.currentTimeMillis();
                activeRecord.status = 0;
                storage.addRecord(activeRecord);

                handler.post(() -> {
                    statusText.setText(R.string.status_building);
                    appendLog("Workflow dispatched. Waiting for the build to finish...\n");
                });

                // 5. Poll until terminal
                poll();

            } catch (Exception e) {
                handler.post(() -> {
                    appendLog("\nERROR: " + e.getMessage() + "\n");
                    statusText.setText(R.string.status_failed);
                    if (activeRecord != null) {
                        activeRecord.status = 2;
                        storage.updateRecord(activeRecord);
                    }
                    running = false;
                    btnBuild.setEnabled(true);
                    btnBuild.setText(R.string.build_again);
                });
            }
        }).start();
    }

    private void poll() {
        if (pollRunnable != null) handler.removeCallbacks(pollRunnable);
        pollRunnable = new Runnable() {
            @Override
            public void run() {
                if (!running) return;
                new Thread(() -> {
                    try {
                        JSONObject run = api.getLatestRun(repoName);
                        if (run != null && !isRunFromThisBuild(run)) run = null;
                        if (run == null) {
                            handler.post(() -> appendLog("Waiting for GitHub to create this build's workflow run...\n"));
                        } else {
                            String state = run.optString("status");
                            String concl = run.optString("conclusion");
                            currentRunId = run.optLong("id");

                            JSONArray jobs = api.getJobs(repoName, currentRunId);
                            JSONObject firstJob = null;
                            if (jobs != null && jobs.length() > 0) {
                                firstJob = jobs.getJSONObject(0);
                                currentJobId = String.valueOf(firstJob.optLong("id"));
                                String jobState = firstJob.optString("status", "queued");
                                JSONArray steps = firstJob.optJSONArray("steps");
                                if (steps != null) {
                                    StringBuilder summary = new StringBuilder();
                                    for (int i = 0; i < steps.length(); i++) {
                                        JSONObject step = steps.optJSONObject(i);
                                        if (step == null) continue;
                                        String stepName = step.optString("name", "Step " + (i + 1));
                                        String stepStatus = step.optString("status", "queued");
                                        String stepConclusion = step.optString("conclusion", "");
                                        summary.append(stepName).append(" — ").append(stepStatus);
                                        if (!stepConclusion.isEmpty()) summary.append(" (").append(stepConclusion).append(")");
                                        summary.append('\n');
                                    }
                                    String newSummary = summary.toString();
                                    if (!newSummary.equals(lastStepSummary) && !newSummary.isEmpty()) {
                                        lastStepSummary = newSummary;
                                        handler.post(() -> appendLog("\n--- Workflow steps ---\n" + newSummary));
                                    }
                                }
                                if ("in_progress".equals(jobState) && !lastStepSummary.isEmpty()) {
                                    handler.post(() -> statusText.setText("Building — " + jobState));
                                }
                                if (currentJobId != null) streamLogs();
                            }

                            if (state.equals("completed")) {
                                boolean success = "success".equals(concl);
                                String finalJobLogs = "";
                                if (currentJobId != null && !finalLogsRequested) {
                                    finalLogsRequested = true;
                                    try { finalJobLogs = api.getJobLogs(repoName, Long.parseLong(currentJobId)); }
                                    catch (Exception logError) { finalJobLogs = "\n[Could not retrieve full job logs: " + logError.getMessage() + "]\n"; }
                                }
                                final String logsToShow = finalJobLogs;
                                handler.post(() -> {
                                    if (!logsToShow.isEmpty()) appendLog("\n=== GITHUB JOB LOGS ===\n" + logsToShow + "\n");
                                    appendLog("\nWorkflow " + (success ? "SUCCEEDED" : "FAILED") + " (conclusion=" + concl + ")\n");
                                    if (success) {
                                        statusText.setText(R.string.status_success);
                                        activeRecord.status = 1;
                                        downloadApk(true);
                                    } else {
                                        statusText.setText(R.string.status_failed);
                                        activeRecord.status = 2;
                                    }
                                    storage.updateRecord(activeRecord);
                                    running = false;
                                    btnBuild.setEnabled(true);
                                    btnBuild.setText(R.string.build_again);
                                });
                                return;
                            }
                        }
                    } catch (Exception e) {
                        handler.post(() -> appendLog("Poll error: " + e.getMessage() + "\n"));
                    }
                    handler.postDelayed(this, 6000);
                }).start();
            }
        };
        handler.post(pollRunnable);
    }

    private boolean isRunFromThisBuild(JSONObject run) {
        String createdAt = run.optString("created_at", "");
        if (createdAt.isEmpty() || dispatchStartedAt <= 0L) return true;
        try {
            java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US);
            format.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            java.util.Date created = format.parse(createdAt);
            return created != null && created.getTime() >= dispatchStartedAt - 30000L;
        } catch (Exception ignored) {
            return true;
        }
    }

    private void streamLogs() {
        // GitHub's job-log endpoint is polled periodically. GitHub may not expose
        // the complete console archive until the job has completed.
        if (System.currentTimeMillis() - lastLiveLogFetchAt < 25000L) return;
        lastLiveLogFetchAt = System.currentTimeMillis();
        new Thread(() -> {
            try {
                String logs = api.getJobLogs(repoName, Long.parseLong(currentJobId));
                if (logs != null && !logs.isEmpty() && !logs.equals(lastLiveLogSnapshot)) {
                    String previous = lastLiveLogSnapshot;
                    lastLiveLogSnapshot = logs;
                    String addition = (!previous.isEmpty() && logs.startsWith(previous))
                            ? logs.substring(previous.length())
                            : "\\n--- GitHub workflow console output ---\\n" + logs;
                    if (!addition.isEmpty()) appendLog(addition);
                }
            } catch (Exception logError) {
                String message = logError.getMessage() == null ? "" : logError.getMessage();
                if (!message.contains("HTTP 404") && !message.contains("HTTP 410")) {
                    handler.post(() -> appendLog("Log refresh: " + message + "\\n"));
                }
            }
        }).start();
    }

    // APK download
    // ----------------------------------------------------------------

    private void downloadApk() {
        if (currentRunId <= 0) return;
        downloadApk(false);
    }

    private void downloadApk(boolean silent) {
        new Thread(() -> {
            try {
                JSONObject artifacts = api.getArtifacts(repoName, currentRunId);
                JSONArray arr = artifacts != null ? artifacts.optJSONArray("artifacts") : null;
                if (arr == null || arr.length() == 0) {
                    handler.post(() -> {
                        if (!silent) Toast.makeText(this, R.string.no_artifact, Toast.LENGTH_LONG).show();
                        appendLog("No artifact found in this run.\n");
                    });
                    return;
                }
                JSONObject first = arr.getJSONObject(0);
                String name = first.optString("name");
                String dlUrl = "https://api.github.com/repos/" + api.getAuthenticatedUsername()
                        + "/" + repoName + "/actions/artifacts/" + first.optLong("id") + "/zip";
                File dir = StudioApp.getStorageRoot();
                if (!dir.exists()) dir.mkdirs();
                File outFile = new File(dir, name + ".zip");
                appendLog("Downloading " + name + "...\n");
                api.downloadTo(dlUrl, outFile);
                appendLog("Downloaded " + Utils.formatBytes(outFile.length()) + ". Unpacking...\n");
                // unzip
                File appDir = new File(dir, name);
                Utils.unzipTo(outFile, appDir);
                File apk = findApk(appDir);
                if (apk != null) {
                    activeRecord.downloadedFile = apk.getAbsolutePath();
                    String neonDownloadUrl = uploadApkToNeon(apk);
                    activeRecord.apkUrl = neonDownloadUrl;
                    storage.updateRecord(activeRecord);
                    appendLog("APK uploaded to Neon Object Storage. Secure download link is ready.\\n");
                    appendLog("APK ready: " + apk.getName() + " (" + Utils.formatBytes(apk.length()) + ")\\n");
                    handler.post(() -> {
                        btnDownload.setEnabled(true);
                        btnDownload.setText(R.string.download_apk);
                        statusText.setText(R.string.status_success);
                        statusText.setTextColor(0xFF2E7D32);
                        btnDownload.setOnClickListener(v -> {
                            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(activeRecord.apkUrl))); }
                            catch (Exception ex) { Toast.makeText(this, "Could not open download link: " + ex.getMessage(), Toast.LENGTH_LONG).show(); }
                        });
                    });
                } else {
                    handler.post(() -> appendLog("No APK found inside the artifact. Check the logs above.\n"));
                }
            } catch (Exception e) {
                handler.post(() -> appendLog("Download error: " + e.getMessage() + "\n"));
            }
        }).start();
    }

    private static final String NEON_API = "https://br-steep-leaf-b59uvinr-apkapi.compute.c-7.us-east-2.aws.neon.tech";

    private String uploadApkToNeon(File apk) throws Exception {
        String token = storage.getToken();
        JSONObject req = new JSONObject(); req.put("fileName", apk.getName());
        JSONObject signed = neonJsonRequest("POST", NEON_API + "/upload-url", req.toString(), token);
        String key = signed.getString("key");
        HttpURLConnection put = (HttpURLConnection) new URL(signed.getString("uploadUrl")).openConnection();
        put.setRequestMethod("PUT"); put.setDoOutput(true);
        put.setRequestProperty("Content-Type", "application/vnd.android.package-archive");
        put.setConnectTimeout(30000); put.setReadTimeout(120000);
        try (java.io.InputStream in = new java.io.FileInputStream(apk); java.io.OutputStream out = put.getOutputStream()) {
            byte[] b = new byte[16384]; int n; while ((n=in.read(b))!=-1) out.write(b,0,n);
        }
        int code=put.getResponseCode();
        if(code<200||code>=300){String e=put.getErrorStream()==null?"":readStream(put.getErrorStream());put.disconnect();throw new Exception("Neon upload failed: HTTP "+code+" "+e);}
        put.disconnect();
        String q=java.net.URLEncoder.encode(key,"UTF-8");
        return neonJsonRequest("GET",NEON_API+"/download-url?key="+q,null,token).getString("downloadUrl");
    }

    private JSONObject neonJsonRequest(String method,String endpoint,String body,String token) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
        c.setRequestMethod(method); c.setRequestProperty("Authorization","Bearer "+token);
        c.setRequestProperty("Accept","application/json"); c.setConnectTimeout(30000); c.setReadTimeout(60000);
        if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(java.io.OutputStream o=c.getOutputStream()){o.write(body.getBytes("UTF-8"));}}
        int code=c.getResponseCode(); String response=readStream(code>=200&&code<300?c.getInputStream():c.getErrorStream()); c.disconnect();
        if(code<200||code>=300)throw new Exception("Neon API failed: HTTP "+code+" "+response);
        return new JSONObject(response);
    }

    private String readStream(java.io.InputStream in) throws Exception {
        if(in==null)return ""; try(java.io.ByteArrayOutputStream o=new java.io.ByteArrayOutputStream()){
            byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)o.write(b,0,n);return new String(o.toByteArray(),"UTF-8");}
    }

    /** Recursively find the first .apk inside dir. */
    private File findApk(File dir) {
        File f = new File(dir, "app-debug.apk");
        if (f.exists()) return f;
        f = new File(dir, "app-release.apk");
        if (f.exists()) return f;
        return findApkRecursive(dir, 5);
    }

    private File findApkRecursive(File dir, int depth) {
        if (depth < 0) return null;
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File c : files) {
            if (c.isDirectory()) {
                File found = findApkRecursive(c, depth - 1);
                if (found != null) return found;
            } else if (c.getName().endsWith(".apk")) {
                return c;
            }
        }
        return null;
    }

    private void offerOpenApk(File apk) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(R.string.apk_ready)
                .setMessage(apk.getName() + "\n" + Utils.formatBytes(apk.length()) + "\n\n" + apk.getAbsolutePath())
                .setPositiveButton(R.string.install, (d, w) -> {
                    try {
                        Uri uri = androidx.core.content.FileProvider.getUriForFile(this,
                                getPackageName() + ".fileprovider", apk);
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setDataAndType(uri, "application/vnd.android.package-archive");
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(i);
                    } catch (Exception e) {
                        // Fallback: open via the document file path
                        try {
                            Intent i = new Intent(Intent.ACTION_VIEW, Uri.fromFile(apk));
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(i);
                        } catch (Exception e2) {
                            Toast.makeText(this, "Could not open APK: " + e2.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    // ----------------------------------------------------------------
    // UI helpers
    // ----------------------------------------------------------------

    private void showLogsOnly() {
        progressView.setVisibility(View.GONE);
        logsView.setVisibility(View.VISIBLE);
    }

    private void appendLog(String text) {
        if (text == null) return;
        final String t = text;
        handler.post(() -> {
            logText.append(t);
            logText.scrollTo(0, logText.getBottom());
        });
    }
}
