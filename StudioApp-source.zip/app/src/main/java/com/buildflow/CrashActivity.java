package com.buildflow;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;

/** Displays the last fatal crash report and lets the user copy it. */
public class CrashActivity extends AppCompatActivity {

    public static final String EXTRA_CRASH_FILE = "crash_file";
    private String crashLog = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String path = getIntent().getStringExtra(EXTRA_CRASH_FILE);
        if (path != null) {
            try {
                try (FileInputStream in = new FileInputStream(new File(path));
                     ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = in.read(buffer)) != -1) bytes.write(buffer, 0, count);
                    crashLog = new String(bytes.toByteArray(), StandardCharsets.UTF_8);
                }
            } catch (Exception e) {
                crashLog = "Crash log could not be read.\n" + e;
            }
        }
        if (crashLog.trim().isEmpty()) {
            crashLog = "The app stopped unexpectedly, but no crash details were saved.";
        }

        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFF101318);

        TextView title = new TextView(this);
        title.setText("App crashed");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(24);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Crash details are shown below. Copy the log and share it to help diagnose the problem.");
        subtitle.setTextColor(0xFFB8C0CC);
        subtitle.setTextSize(14);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(8);
        subParams.bottomMargin = dp(16);
        root.addView(subtitle, subParams);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        TextView logView = new TextView(this);
        logView.setText(crashLog);
        logView.setTextColor(0xFFE6EAF0);
        logView.setTextSize(12);
        logView.setTextIsSelectable(true);
        logView.setTypeface(android.graphics.Typeface.MONOSPACE);
        logView.setPadding(dp(12), dp(12), dp(12), dp(12));
        logView.setBackgroundColor(0xFF202630);
        scroll.addView(logView, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        Button copy = new Button(this);
        copy.setText("Copy crash logs");
        copy.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("StudioApp crash log", crashLog));
                Toast.makeText(this, "Crash logs copied", Toast.LENGTH_SHORT).show();
            }
        });
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, -2);
        buttonParams.topMargin = dp(16);
        root.addView(copy, buttonParams);

        setContentView(root);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
