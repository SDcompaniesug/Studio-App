package com.buildflow.storage;

import android.content.Context;
import android.content.SharedPreferences;

import com.buildflow.model.BuildRecord;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Local persistence for settings and build history.
 */
public class AppStorage {

    private static final String PREFS = "studio_app_prefs";
    private static final String KEY_TOKEN = "github_token";
    private static final String KEY_HISTORY = "build_history";

    private final SharedPreferences prefs;

    public AppStorage(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String getToken() {
        return prefs.getString(KEY_TOKEN, "");
    }

    public void setToken(String token) {
        prefs.edit().putString(KEY_TOKEN, token).apply();
    }

    public boolean hasToken() {
        return getToken() != null && !getToken().trim().isEmpty();
    }

    public List<BuildRecord> getHistory() {
        List<BuildRecord> list = new ArrayList<>();
        try {
            String json = prefs.getString(KEY_HISTORY, "");
            if (json == null || json.isEmpty()) return list;
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                BuildRecord r = new BuildRecord();
                r.repoName = o.optString("repoName", "");
                r.branch = o.optString("branch", "");
                r.debugBuild = o.optBoolean("debugBuild");
                r.timestamp = o.optLong("timestamp");
                r.status = o.optInt("status");
                r.apkUrl = o.optString("apkUrl");
                r.downloadedFile = o.optString("downloadedFile");
                list.add(r);
            }
        } catch (JSONException ignored) {
        }
        return list;
    }

    public void addRecord(BuildRecord record) {
        List<BuildRecord> list = getHistory();
        list.add(0, record);
        while (list.size() > 100) {
            list.remove(list.size() - 1);
        }
        save(list);
    }

    public void updateRecord(BuildRecord record) {
        List<BuildRecord> list = getHistory();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) == record) {
                save(list);
                return;
            }
        }
        // not in list yet (record created later), just save a copy
        addRecord(record);
    }

    public void removeRecordsForRepo(String repoName) {
        List<BuildRecord> list = getHistory();
        for (int i = list.size() - 1; i >= 0; i--) {
            if (repoName.equalsIgnoreCase(list.get(i).repoName)) list.remove(i);
        }
        save(list);
    }

    private void save(List<BuildRecord> list) {
        try {
            JSONArray arr = new JSONArray();
            for (BuildRecord r : list) {
                JSONObject o = new JSONObject();
                o.put("repoName", r.repoName);
                o.put("branch", r.branch);
                o.put("debugBuild", r.debugBuild);
                o.put("timestamp", r.timestamp);
                o.put("status", r.status);
                o.put("apkUrl", r.apkUrl == null ? "" : r.apkUrl);
                o.put("downloadedFile", r.downloadedFile == null ? "" : r.downloadedFile);
                arr.put(o);
            }
            prefs.edit().putString(KEY_HISTORY, arr.toString()).apply();
        } catch (JSONException ignored) {
        }
    }
}
