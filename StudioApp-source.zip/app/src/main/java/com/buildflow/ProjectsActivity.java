package com.buildflow;

import android.content.Intent;
import android.net.Uri;
import androidx.core.content.FileProvider;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.buildflow.model.BuildRecord;
import com.buildflow.storage.AppStorage;
import com.buildflow.api.GitHubApi;
import com.buildflow.util.Utils;

import java.io.File;
import java.util.List;

/**
 * My Projects screen: lists every build record and lets the user
 * download or install the resulting APK.
 */
public class ProjectsActivity extends AppCompatActivity {

    private RecyclerView recycler;
    private TextView empty;
    private AppStorage storage;
    private ImageButton back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_projects);
        storage = new AppStorage(this);

        back = findViewById(R.id.backBtn);
        recycler = findViewById(R.id.projectsRecycler);
        empty = findViewById(R.id.projectsEmpty);

        back.setOnClickListener(v -> finish());
        recycler.setLayoutManager(new LinearLayoutManager(this));
        refresh();
    }

    private void refresh() {
        List<BuildRecord> list = storage.getHistory();
        if (list.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            recycler.setVisibility(View.GONE);
        } else {
            empty.setVisibility(View.GONE);
            recycler.setVisibility(View.VISIBLE);
            recycler.setAdapter(new ProjectsAdapter(list));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void deleteRemoteProject(String repoName) {
        if (!storage.hasToken()) {
            Toast.makeText(this, "Add your GitHub token in Settings first.", Toast.LENGTH_LONG).show();
            return;
        }
        new Thread(() -> {
            try {
                new GitHubApi(this).deleteRepository(repoName);
                storage.removeRecordsForRepo(repoName);
                runOnUiThread(() -> { Toast.makeText(this, "GitHub repository deleted.", Toast.LENGTH_SHORT).show(); refresh(); });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Delete failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private class ProjectsAdapter extends RecyclerView.Adapter<ProjectsAdapter.VH> {
        final List<BuildRecord> items;
        ProjectsAdapter(List<BuildRecord> items) { this.items = items; }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull android.view.ViewGroup parent, int viewType) {
            View v = getLayoutInflater().inflate(R.layout.item_project, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            BuildRecord r = items.get(position);
            h.name.setText(r.repoName);
            h.branch.setText(r.branch);
            h.when.setText(Utils.formatTime(r.timestamp));
            h.type.setText(r.debugBuild ? R.string.build_type_debug : R.string.build_type_release);
            if (r.status == 1) {
                h.status.setText(R.string.status_success);
                h.status.setTextColor(0xFF2E7D32);
            } else if (r.status == 2) {
                h.status.setText(R.string.status_failed);
                h.status.setTextColor(0xFFD32F2F);
            } else {
                h.status.setText(R.string.status_pending);
                h.status.setTextColor(0xFF1565C0);
            }
            h.installBtn.setEnabled(r.status == 1 && r.downloadedFile != null && !r.downloadedFile.isEmpty());
            h.installBtn.setOnClickListener(v -> {
                try {
                    Uri uri = FileProvider.getUriForFile(ProjectsActivity.this, getPackageName() + ".fileprovider", new File(r.downloadedFile));
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(uri, "application/vnd.android.package-archive");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(ProjectsActivity.this, "Open failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
            h.itemView.setOnClickListener(v -> {
                Intent i = new Intent(ProjectsActivity.this, BuildActivity.class);
                i.putExtra(BuildActivity.EXTRA_ACTION, BuildActivity.ACTION_VIEW);
                i.putExtra(BuildActivity.EXTRA_REPO, r.repoName);
                startActivity(i);
            });
            h.deleteBtn.setOnClickListener(v -> new androidx.appcompat.app.AlertDialog.Builder(ProjectsActivity.this)
                    .setTitle("Delete project?")
                    .setMessage("Permanently delete GitHub repository " + r.repoName + " and remove its build history?")
                    .setNegativeButton(android.R.string.cancel, null)
                    .setPositiveButton("Delete repository", (dialog, which) -> deleteRemoteProject(r.repoName))
                    .show());
        }

        @Override
        public int getItemCount() { return items.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView name, branch, when, type, status;
            View installBtn, deleteBtn;
            VH(View v) {
                super(v);
                name = v.findViewById(R.id.itemName);
                branch = v.findViewById(R.id.itemBranch);
                when = v.findViewById(R.id.itemWhen);
                type = v.findViewById(R.id.itemType);
                status = v.findViewById(R.id.itemStatus);
                installBtn = v.findViewById(R.id.btnInstall);
                deleteBtn = v.findViewById(R.id.btnDeleteProject);
            }
        }
    }
}
