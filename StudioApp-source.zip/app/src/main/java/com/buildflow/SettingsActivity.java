package com.buildflow;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.buildflow.api.GitHubApi;
import com.buildflow.storage.AppStorage;

import org.json.JSONObject;

/**
 * Settings screen: manage the GitHub token and account.
 */
public class SettingsActivity extends AppCompatActivity {

    private AppStorage storage;
    private EditText tokenInput;
    private TextView tokenStatus;
    private Button saveBtn;
    private Button testBtn;
    private TextView accountInfo;
    private ImageButton back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        storage = new AppStorage(this);

        back = findViewById(R.id.backBtn);
        tokenInput = findViewById(R.id.tokenInput);
        tokenStatus = findViewById(R.id.tokenStatus);
        saveBtn = findViewById(R.id.btnSaveToken);
        testBtn = findViewById(R.id.btnTestToken);
        accountInfo = findViewById(R.id.accountInfo);

        back.setOnClickListener(v -> finish());
        saveBtn.setOnClickListener(v -> saveToken());
        testBtn.setOnClickListener(v -> testToken());
        tokenInput.setText(storage.getToken());
        updateStatus();
    }

    private void updateStatus() {
        if (storage.hasToken()) {
            tokenStatus.setText(R.string.token_set);
            tokenStatus.setTextColor(0xFF2E7D32);
            testBtn.setEnabled(true);
        } else {
            tokenStatus.setText(R.string.token_missing);
            tokenStatus.setTextColor(0xFFD32F2F);
            testBtn.setEnabled(false);
        }
    }

    private void saveToken() {
        String t = tokenInput.getText().toString().trim();
        if (t.isEmpty()) {
            Toast.makeText(this, R.string.token_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        storage.setToken(t);
        updateStatus();
        Toast.makeText(this, R.string.token_saved, Toast.LENGTH_SHORT).show();
    }

    private void testToken() {
        new Thread(() -> {
            try {
                GitHubApi api = new GitHubApi(SettingsActivity.this);
                JSONObject o = api.getUser();
                final String login = o.optString("login");
                runOnUiThread(() -> {
                    accountInfo.setText(getString(R.string.account_username, login));
                    Toast.makeText(SettingsActivity.this, R.string.token_valid, Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    accountInfo.setText("");
                    Toast.makeText(SettingsActivity.this,
                            getString(R.string.token_invalid) + "  " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
}
