package com.buildflow;

import android.app.Application;
import android.content.Intent;
import android.os.Build;
import android.os.Process;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import java.io.File;

/**
 * Application class for Studio App.
 * Holds the shared storage root where user projects and builds live.
 */
public class StudioApp extends Application {

    private static final String CRASH_FILE = "last_crash.txt";
    private static StudioApp instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                StringWriter sw = new StringWriter();
                throwable.printStackTrace(new PrintWriter(sw));
                String report = "StudioApp crash report\n"
                        + "Time: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()) + "\n"
                        + "Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n"
                        + "Android: " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\n"
                        + "Thread: " + thread.getName() + "\n\n" + sw;

                File crashFile = new File(getFilesDir(), CRASH_FILE);
                try (FileOutputStream out = new FileOutputStream(crashFile, false)) {
                    out.write(report.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }

                Intent intent = new Intent(getApplicationContext(), CrashActivity.class);
                intent.putExtra(CrashActivity.EXTRA_CRASH_FILE, crashFile.getAbsolutePath());
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK
                        | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                startActivity(intent);
            } catch (Throwable ignored) {
                // Keep crash reporting failures from masking the original exception.
            }
            android.os.SystemClock.sleep(300);
            Process.killProcess(Process.myPid());
            System.exit(10);
        });
    }

    public static File getStorageRoot() {
        if (instance == null) return new File("StudioApp");
        File root = instance.getExternalFilesDir(null);
        if (root != null) return new File(root, "StudioApp");
        return new File(instance.getFilesDir(), "StudioApp");
    }
}
