package com.buildflow.api;

import android.content.Context;
import android.util.Log;

import com.buildflow.storage.AppStorage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * GitHub API client using plain HttpURLConnection (no external libs).
 * All methods are blocking and MUST be called off the main thread.
 */
public class GitHubApi {

    private static final String TAG = "GitHubApi";
    private static final String BASE = "https://api.github.com";

    private final String token;

    public GitHubApi(Context context) {
        AppStorage storage = new AppStorage(context);
        this.token = storage.getToken();
    }

    /** Result of creating a repo. */
    public static class CreatedRepo {
        public String name;
        public String htmlUrl;
        public String defaultBranch;
    }

    /**
     * Creates a private repository with the given name.
     * If it already exists, returns the existing repo info.
     */
    public CreatedRepo createRepository(String name) throws Exception {
        CreatedRepo repo = new CreatedRepo();
        String url = BASE + "/user/repos";
        JSONObject body = new JSONObject();
        body.put("name", name);
        body.put("private", true);
        int code = post(url, body.toString(), null, null);
        if (code == 201 || code == 200) {
            JSONObject o = lastResponse;
            repo.name = o.optString("name", name);
            repo.htmlUrl = o.optString("html_url", "");
            repo.defaultBranch = o.optString("default_branch", "main");
            return repo;
        } else if (code == 422) {
            // already exists: fetch it
            String repoUrl = BASE + "/repos/" + currentUsername() + "/" + name;
            int c2 = get(repoUrl, null);
            if (c2 == 200) {
                JSONObject o = lastResponse;
                repo.name = o.optString("name", name);
                repo.htmlUrl = o.optString("html_url", "");
                repo.defaultBranch = o.optString("default_branch", "main");
                return repo;
            }
        }
        throw new Exception("Failed to create repo: HTTP " + code + " " + lastErrorBody);
    }

    private String currentUsername() throws Exception {
        get(BASE + "/user", null);
        return lastResponse.optString("login", "");
    }

    private JSONObject lastResponse = new JSONObject();
    private String lastErrorBody = "";

    /**
     * Creates a branch from the default branch, pushes files, and
     * sets up the GitHub Actions workflow.
     *
     * @param repoName  repository slug (owner-less, we use our own)
     * @param zipFile   the local .zip file of the user's project
     */
    public void pushProjectFiles(String repoName, File zipFile, String sourceDir) throws Exception {
        byte[] zipBytes = sanitizeProjectZip(readAllBytes(zipFile));
        // base64 encode
        String zipBase64 = android.util.Base64.encodeToString(zipBytes, android.util.Base64.NO_WRAP);

        // Create the source directory with a placeholder if empty
        String sourcePath = sourceDir == null ? "" : sourceDir;
        // Upload the zip to the source path (so user can unzip later)
        String zipPath = (sourcePath.isEmpty() ? "" : sourcePath + "/") + "project.zip";
        uploadFile(repoName, "main", zipPath, zipBase64, "Project source zip");

        // Upload workflow
        String workflowContent = buildWorkflowYaml(sourceDir);
        String workflowPath = ".github/workflows/build-apk.yml";
        uploadFile(repoName, "main", workflowPath,
                android.util.Base64.encodeToString(workflowContent.getBytes("UTF-8"), android.util.Base64.NO_WRAP),
                "CI build workflow");

        // README upload intentionally omitted; it is optional for the APK build.
    }

    /**
     * Triggers a workflow run on the main branch with build_type input.
     */
    public void dispatchWorkflow(String repoName, String buildType) throws Exception {
        String url = BASE + "/repos/" + currentUsername() + "/" + repoName + "/actions/workflows/build-apk.yml/dispatches";
        JSONObject body = new JSONObject();
        body.put("ref", "main");
        JSONObject inputs = new JSONObject();
        inputs.put("build_type", buildType);
        body.put("inputs", inputs);
        int code = post(url, body.toString(), null, null);
        if (code != 204 && code != 200) {
            throw new Exception("Dispatch failed: HTTP " + code + " " + lastErrorBody);
        }
    }

    /**
     * Polls the most recent workflow runs until one is in the requested state.
     */
    public JSONObject getLatestRun(String repoName) throws Exception {
        String url = BASE + "/repos/" + currentUsername() + "/" + repoName + "/actions/runs?per_page=1";
        int code = get(url, null);
        if (code != 200) throw new Exception("HTTP " + code + " " + lastErrorBody);
        JSONArray arr = lastResponse.optJSONArray("workflow_runs");
        if (arr == null || arr.length() == 0) return null;
        return arr.getJSONObject(0);
    }

    /**
     * Fetches logs of a specific job.
     */
    public String getJobLogs(String repoName, long jobId) throws Exception {
        String endpoint = BASE + "/repos/" + currentUsername() + "/" + repoName
                + "/actions/jobs/" + jobId + "/logs";
        HttpURLConnection apiConn = (HttpURLConnection) new URL(endpoint).openConnection();
        apiConn.setInstanceFollowRedirects(false);
        apiConn.setRequestProperty("Accept", "application/vnd.github+json");
        apiConn.setRequestProperty("Authorization", "Bearer " + token);
        apiConn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        apiConn.setRequestProperty("User-Agent", "StudioApp/1.0");
        apiConn.setConnectTimeout(30000);
        apiConn.setReadTimeout(120000);
        int code = apiConn.getResponseCode();
        if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
            String location = apiConn.getHeaderField("Location");
            apiConn.disconnect();
            if (location == null || location.trim().isEmpty()) throw new Exception("GitHub returned a log redirect without a download URL.");
            // The redirect is a temporary signed URL; do not send the GitHub token to it.
            HttpURLConnection fileConn = (HttpURLConnection) new URL(location).openConnection();
            fileConn.setConnectTimeout(30000);
            fileConn.setReadTimeout(120000);
            int fileCode = fileConn.getResponseCode();
            if (fileCode != 200) {
                String error = readAll(fileConn.getErrorStream());
                fileConn.disconnect();
                throw new Exception("Job log download failed: HTTP " + fileCode + " " + error);
            }
            String logs = readAll(fileConn.getInputStream());
            fileConn.disconnect();
            return logs;
        }
        if (code != 200) {
            String error = readAll(apiConn.getErrorStream());
            apiConn.disconnect();
            throw new Exception("Get job logs failed: HTTP " + code + " " + error);
        }
        String logs = readAll(apiConn.getInputStream());
        apiConn.disconnect();
        return logs;
    }

    /**
     * Returns the jobs of a workflow run (most recent first).
     */
    public JSONArray getJobs(String repoName, long runId) throws Exception {
        String url = BASE + "/repos/" + currentUsername() + "/" + repoName
                + "/actions/runs/" + runId + "/jobs?per_page=10";
        int code = get(url, null);
        if (code != 200) throw new Exception("Get workflow jobs failed: HTTP " + code + " " + lastErrorBody);
        return lastResponse.optJSONArray("jobs");
    }

    /**
     * Fetches build artifacts for a workflow run.
     */
    public JSONObject getArtifacts(String repoName, long runId) throws Exception {
        String url = BASE + "/repos/" + currentUsername() + "/" + repoName
                + "/actions/runs/" + runId + "/artifacts?per_page=100";
        int code = get(url, null);
        if (code != 200) throw new Exception("Get workflow artifacts failed: HTTP " + code + " " + lastErrorBody);
        return lastResponse;
    }

    /**
     * Returns the authenticated user (for the "test token" flow).
     */
    public JSONObject getUser() throws Exception {
        int code = get(BASE + "/user", null);
        if (code != 200) throw new Exception("HTTP " + code + " " + lastErrorBody);
        return lastResponse;
    }

    public String getAuthenticatedUsername() throws Exception {
        return currentUsername();
    }

    /**
     * Downloads a file from a URL into a destination file.
     */
    public void downloadTo(String url, File dest) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setInstanceFollowRedirects(false);
        conn.setRequestProperty("Accept", "application/vnd.github+json");
        conn.setRequestProperty("Authorization", "Bearer " + token);
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        conn.setRequestProperty("User-Agent", "StudioApp/1.0");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(120000);
        int code = conn.getResponseCode();
        if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
            String location = conn.getHeaderField("Location");
            conn.disconnect();
            if (location == null || location.trim().isEmpty()) throw new Exception("GitHub artifact redirect did not include a download URL.");
            conn = (HttpURLConnection) new URL(location).openConnection();
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(120000);
            code = conn.getResponseCode();
        }
        if (code != 200) {
            String error = readAll(conn.getErrorStream());
            conn.disconnect();
            throw new Exception("Download failed: HTTP " + code + " " + error);
        }
        try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            out.flush();
        } finally { conn.disconnect(); }
    }

    /** Deletes the complete remote GitHub repository. Call only after user confirmation. */
    public void deleteRepository(String repoName) throws Exception {
        String endpoint = BASE + "/repos/" + currentUsername() + "/" + repoName;
        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setRequestMethod("DELETE");
        conn.setRequestProperty("Accept", "application/vnd.github+json");
        conn.setRequestProperty("Authorization", "Bearer " + token);
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        conn.setRequestProperty("User-Agent", "StudioApp/1.0");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(60000);
        int code = conn.getResponseCode();
        String error = code >= 200 && code < 300 ? "" : readAll(conn.getErrorStream());
        conn.disconnect();
        if (code != 204) throw new Exception("GitHub repository deletion failed: HTTP " + code + " " + error);
    }

    // Low level HTTP helpers
    // ----------------------------------------------------------------

    private static int lastCode;
    private static String lastRawResponse = "";

    private int get(String url, JSONObject ignoreBody) throws Exception {
        return request("GET", url, null, null);
    }

    private int post(String url, String body, String extraHeader, Runnable ignored) throws Exception {
        return request("POST", url, body, extraHeader);
    }

    private int request(String method, String url, String body, String extraHeader) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod(method);
        conn.setRequestProperty("Accept", "application/vnd.github+json");
        conn.setRequestProperty("Authorization", "Bearer " + token);
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        conn.setRequestProperty("User-Agent", "StudioApp/1.0");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(120000);
        if (method.equals("POST") || method.equals("PUT")) {
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
        }
        if (body != null && !body.isEmpty()) {
            byte[] bytes = body.getBytes("UTF-8");
            conn.setRequestProperty("Content-Length", String.valueOf(bytes.length));
            try (java.io.OutputStream os = conn.getOutputStream()) {
                os.write(bytes);
            }
        }
        int code = conn.getResponseCode();
        lastCode = code;
        lastRawResponse = "";
        if (code >= 200 && code < 300) {
            lastRawResponse = readAll(conn.getInputStream());
            try {
                lastResponse = new JSONObject(lastRawResponse);
            } catch (Exception e) {
                lastResponse = new JSONObject();
            }
            lastErrorBody = "";
        } else {
            lastErrorBody = readAll(conn.getErrorStream());
        }
        conn.disconnect();
        return code;
    }

    private void uploadFile(String repoName, String branch, String path, String base64Content, String message) throws Exception {
        String owner = currentUsername();
        // Look up the existing file to obtain its sha (only needed when overwriting)
        String fileUrl = BASE + "/repos/" + owner + "/" + repoName + "/contents/" + path + "?ref=" + branch;
        int code = get(fileUrl, null);
        String sha = null;
        if (code == 200) {
            sha = lastResponse.optString("sha", null);
        } else if (code != 404) {
            throw new Exception("Failed to inspect " + path + ": HTTP " + code + " " + lastErrorBody);
        }

        JSONObject body = new JSONObject();
        body.put("message", message);
        body.put("branch", branch);
        body.put("content", base64Content);
        if (sha != null) body.put("sha", sha);

        String commitUrl = BASE + "/repos/" + owner + "/" + repoName + "/contents/" + path;
        int c2 = put(commitUrl, body.toString());
        if (c2 != 200 && c2 != 201) {
            // Fallback: the target path may not exist on main yet. Some repos default
            // to a different branch — retry with the existing default branch.
            throw new Exception("Upload failed for " + path + " : HTTP " + c2 + " " + lastErrorBody);
        }
    }

    private int put(String url, String body) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("PUT");
        conn.setRequestProperty("Accept", "application/vnd.github+json");
        conn.setRequestProperty("Authorization", "Bearer " + token);
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        conn.setRequestProperty("User-Agent", "StudioApp/1.0");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(120000);
        byte[] bytes = body.getBytes("UTF-8");
        conn.getOutputStream().write(bytes);
        int code = conn.getResponseCode();
        lastCode = code;
        if (code >= 200 && code < 300) {
            lastRawResponse = readAll(conn.getInputStream());
            lastErrorBody = "";
            try { lastResponse = new JSONObject(lastRawResponse); } catch (Exception e) { lastResponse = new JSONObject(); }
        } else {
            lastErrorBody = readAll(conn.getErrorStream());
        }
        conn.disconnect();
        return code;
    }

    private String readAll(InputStream in) {
        try {
            if (in == null) return "";
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return new String(out.toByteArray(), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private String readError(HttpURLConnection conn) {
        try {
            return readAll(conn.getErrorStream());
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Removes machine-specific and generated files that should not be sent to
     * GitHub Actions. Also removes the Termux-only AAPT2 override so CI can use
     * the AAPT2 version supplied by the Android Gradle Plugin.
     */
    private static byte[] sanitizeProjectZip(byte[] original) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        ZipInputStream input = new ZipInputStream(new ByteArrayInputStream(original));
        ZipOutputStream zip = new ZipOutputStream(output);
        ZipEntry entry;

        while ((entry = input.getNextEntry()) != null) {
            String name = entry.getName().replace('\\', '/');
            String[] parts = name.split("/");
            boolean skip = false;

            for (String part : parts) {
                if (part.equals(".gradle") || part.equals(".idea")
                        || part.equals("captures") || part.equals("build")) {
                    skip = true;
                    break;
                }
            }

            String baseName = parts.length == 0 ? name : parts[parts.length - 1];
            if (baseName.equals("local.properties")
                    || baseName.equals(".DS_Store")
                    || baseName.equals("Thumbs.db")) {
                skip = true;
            }

            if (!skip) {
                ByteArrayOutputStream entryBytes = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    entryBytes.write(buffer, 0, count);
                }
                byte[] data = entryBytes.toByteArray();

                if (baseName.equals("gradle.properties") && !entry.isDirectory()) {
                    String content = new String(data, "UTF-8");
                    String[] lines = content.split("\\r?\\n", -1);
                    StringBuilder cleaned = new StringBuilder();
                    for (String line : lines) {
                        if (!line.trim().startsWith("android.aapt2FromMavenOverride=")) {
                            cleaned.append(line).append('\n');
                        }
                    }
                    data = cleaned.toString().getBytes("UTF-8");
                }

                ZipEntry cleanEntry = new ZipEntry(name);
                if (entry.getTime() >= 0) cleanEntry.setTime(entry.getTime());
                zip.putNextEntry(cleanEntry);
                if (!entry.isDirectory()) zip.write(data);
                zip.closeEntry();
            }
            input.closeEntry();
        }

        input.close();
        zip.close();
        return output.toByteArray();
    }

    private static byte[] readAllBytes(File f) throws Exception {
        java.io.FileInputStream in = new java.io.FileInputStream(f);
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close();
        return out.toByteArray();
    }

    /** Builds a short README committed alongside the uploaded project. */
    private String buildReadme(String repoName, String sourceDir) {
        String projectLocation = (sourceDir == null || sourceDir.trim().isEmpty())
                ? "project.zip (repository root)"
                : sourceDir + "/project.zip";
        return "# " + repoName + "\n\n"
                + "This repository was created by Studio App to build an Android APK with GitHub Actions.\n\n"
                + "## Project source\n\n"
                + "The uploaded Gradle project is stored at `" + projectLocation + "`.\n\n"
                + "## Build\n\n"
                + "Open the **Actions** tab and run the **Build APK** workflow. "
                + "Choose `debug` or `release` as the build type.\n";
    }

    // ----------------------------------------------------------------
    // Workflow YAML generator
    // ----------------------------------------------------------------

    /**
     * Generates the GitHub Actions workflow that:
     *  - cleans stale gradle caches
     *  - unpacks the uploaded project.zip
     *  - compiles the APK with Gradle (debug or release)
     *  - uploads the APK as an artifact
     */
    private String buildWorkflowYaml(String sourceDir) {
        // Always unpack into a predictable directory. Then detect whether the ZIP
        // contains the Gradle project at its root or inside one enclosing folder.
        return String.join("\n",
                "name: Build APK",
                "on:",
                "  workflow_dispatch:",
                "    inputs:",
                "      build_type:",
                "        description: 'Build type'",
                "        required: true",
                "        default: 'debug'",
                "        type: choice",
                "        options:",
                "          - debug",
                "          - release",
                "",
                "jobs:",
                "  build:",
                "    runs-on: ubuntu-latest",
                "    steps:",
                "      - name: Checkout",
                "        uses: actions/checkout@v4",
                "",
                "      - name: Set up JDK 17",
                "        uses: actions/setup-java@v4",
                "        with:",
                "          distribution: 'temurin'",
                "          java-version: 17",
                "",
                "      - name: Unpack project and locate Gradle root",
                "        run: |",
                "          set -euo pipefail",
                "          mkdir -p project_src",
                "          unzip -q project.zip -d project_src",
                "          if [ -f project_src/gradlew ]; then",
                "            echo \"BUILD_DIR=project_src\" >> $GITHUB_ENV",
                "          else",
                "            WRAPPER=$(find project_src -type f -name gradlew -print -quit)",
                "            if [ -n \"$WRAPPER\" ]; then",
                "              echo \"BUILD_DIR=$(dirname \"$WRAPPER\")\" >> $GITHUB_ENV",
                "            else",
                "              BUILD_FILE=$(find project_src -type f \\( -name build.gradle -o -name build.gradle.kts \\) -print -quit)",
                "              if [ -z \"$BUILD_FILE\" ]; then echo 'No Gradle build file found in ZIP' >&2; exit 1; fi",
                "              echo \"BUILD_DIR=$(dirname \"$BUILD_FILE\")\" >> $GITHUB_ENV",
                "            fi",
                "          fi",
                "",
                "      - name: Build APK",
                "        env:",
                "          BUILD_TYPE: ${{ inputs.build_type }}",
                "        run: |",
                "          set -euo pipefail",
                "          cd \"$BUILD_DIR\"",
                "          if [ -f ./gradlew ]; then chmod +x ./gradlew; GRADLE=./gradlew; else GRADLE=gradle; fi",
                "          if [ \"$BUILD_TYPE\" = \"release\" ]; then",
                "            $GRADLE clean assembleRelease --no-daemon --stacktrace",
                "          else",
                "            $GRADLE clean assembleDebug --no-daemon --stacktrace",
                "          fi",
                "",
                "      - name: Collect APK",
                "        env:",
                "          BUILD_TYPE: ${{ inputs.build_type }}",
                "        run: |",
                "          set -euo pipefail",
                "          cd \"$BUILD_DIR\"",
                "          if [ \"$BUILD_TYPE\" = \"release\" ]; then",
                "            APK=$(find . -type f -name '*.apk' -path '*release*' -print -quit)",
                "          else",
                "            APK=$(find . -type f -name '*.apk' -path '*debug*' -print -quit)",
                "          fi",
                "          if [ -z \"$APK\" ]; then APK=$(find . -type f -name '*.apk' -print -quit); fi",
                "          if [ -z \"$APK\" ]; then echo 'No APK found after Gradle build' >&2; exit 1; fi",
                "          cp \"$APK\" \"$GITHUB_WORKSPACE/build-output.apk\"",
                "          echo \"Collected APK: $APK\"",
                "",
                "      - name: Upload APK artifact",
                "        uses: actions/upload-artifact@v4",
                "        with:",
                "          name: studio-app-${{ inputs.build_type }}",
                "          path: build-output.apk",
                "          if-no-files-found: error"
        );
    }
}
