package com.buildflow.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.format.DateFormat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Small shared helpers.
 */
public final class Utils {

    private Utils() { }

    /** Unzips the given file into the destination directory. */
    public static File unzipTo(File zipFile, File destDir) throws Exception {
        if (!destDir.exists()) destDir.mkdirs();
        ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));
        ZipEntry entry;
        int fileCount = 0;
        while ((entry = zis.getNextEntry()) != null) {
            File out = new File(destDir, entry.getName());
            // Guard against zip-slip
            String canonical = out.getCanonicalPath();
            String canonicalBase = destDir.getCanonicalPath();
            if (!canonical.startsWith(canonicalBase) && !canonical.equals(canonicalBase)) {
                throw new SecurityException("Zip entry escapes destination: " + entry.getName());
            }
            if (entry.isDirectory()) {
                out.mkdirs();
            } else {
                File parent = out.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                FileOutputStream fos = new FileOutputStream(out);
                byte[] buf = new byte[8192];
                int n;
                while ((n = zis.read(buf)) != -1) {
                    fos.write(buf, 0, n);
                }
                fos.close();
                fileCount++;
            }
            zis.closeEntry();
        }
        zis.close();
        if (fileCount == 0) {
            throw new Exception("Zip is empty");
        }
        return destDir;
    }

    /** Copy a file to a destination. */
    public static void copyFile(File src, File dest) throws Exception {
        InputStream in = new FileInputStream(src);
        OutputStream out = new FileOutputStream(dest);
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) {
            out.write(buf, 0, n);
        }
        in.close();
        out.close();
    }

    /** Format a timestamp for display. */
    public static String formatTime(long millis) {
        SimpleDateFormat sdf = new SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.getDefault());
        return sdf.format(new Date(millis));
    }

    /** Format bytes into a human-readable size. */
    public static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.getDefault(), "%.1f KB", bytes / 1024.0);
        return String.format(Locale.getDefault(), "%.2f MB", bytes / (1024.0 * 1024.0));
    }

    /** Sanitize a filename into a safe repo name (no dots/spaces, ≤ 40 chars). */
    public static String sanitizeRepoName(String raw) {
        String s = raw == null ? "" : raw;
        // strip .zip, .tar, etc
        s = s.replaceAll("\\.(zip|tar|gz|tgz|tar\\.gz|rar|7z)$", "");
        // keep letters, digits, dash, underscore; replace rest with dash
        s = s.replaceAll("[^A-Za-z0-9\\-_]", "-");
        s = s.replaceAll("-+", "-");
        s = s.replaceAll("^-+", "").replaceAll("-+$", "");
        if (s.isEmpty()) s = "project";
        if (s.length() > 40) s = s.substring(0, 40);
        return s.toLowerCase(Locale.getDefault());
    }

    public static boolean isNetworkAvailable(Context ctx) {
        ConnectivityManager cm = (ConnectivityManager) ctx.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return true;
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }
}
