package com.buildflow;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Splash screen: shows the app icon centered on a white card.
 * Transitions to HomeActivity after a short delay.
 */
public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // SplashActivity uses Theme.StudioApp.Splash which sets a translucent status bar.
        setContentView(R.layout.activity_splash);

        new Thread(() -> {
            try { Thread.sleep(1300); } catch (InterruptedException ignored) { }
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                startActivity(new Intent(this, HomeActivity.class));
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            });
        }).start();
    }
}
