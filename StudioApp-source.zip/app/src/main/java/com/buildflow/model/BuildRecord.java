package com.buildflow.model;

/**
 * Represents a single build record shown in My Projects.
 */
public class BuildRecord {

    public String repoName;
    public String branch;
    public boolean debugBuild;
    /** epoch millis of when the build was requested */
    public long timestamp;
    public int status;        // 0 = pending/unknown, 1 = success, 2 = failure
    public String apkUrl;     // null until download
    public String downloadedFile; // absolute path once downloaded
}
