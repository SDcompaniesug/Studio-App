# Project-wide / module-wide ProGuard rules
-keep class okhttp3.** { *; }
