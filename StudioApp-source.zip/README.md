# Studio App

A lightweight Android app (Java + XML) that builds **real, installable APKs** on
GitHub Actions without a computer.

## How it works

1. **Settings** — paste your GitHub personal access token (scope: `repo`).
   The app auto-creates a private repository for every project.
2. **Build** — pick a zip of your Gradle project (must contain `gradlew` and
   `build.gradle`). Choose Debug or Release, tap Build.
3. The app uploads your zip + a generated `.github/workflows/build-apk.yml`
   to the new repo, dispatches the workflow, and streams the CI logs in-app.
4. When the build succeeds the APK is downloaded as an artifact, unpacked,
   and offered for install.
5. **My Projects** — every build is listed with status, timestamp, and a
   one-tap install button for any previously downloaded APK.

## The generated workflow

For each project the app writes `.github/workflows/build-apk.yml`:

- **Clean Gradle caches** — removes stale `~/.gradle/caches`, `daemon`, and
  `wrapper/dists` so each CI run starts fresh.
- **Checkout + unpack** — unpacks `project.zip` into the build directory.
- **JDK 17 + Gradle** — sets up `temurin` JDK and pre-warms the Gradle wrapper.
- **Build** — runs `gradlew clean assembleDebug` or `assembleRelease` based on
  the `build_type` dispatch input.
- **Artifact** — copies the resulting `.apk` to `build-output.apk` and uploads
  it as a GitHub Actions artifact named `studio-app-debug` / `studio-app-release`.

## Build the app

This repository is **source only** — no APK is produced on the device.
Open it in **Android Studio** (Hedgehog or later, AGP 8.7.3) and:

```
File → Open → /storage/emulated/0/HM
Sync Gradle → Build → Build APK(s)
```

Or from a machine with the Android SDK:

```bash
cd /path/to/HM
./gradlew assembleDebug   # → app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease # → app/build/outputs/apk/release/app-release.apk
```

## Package

- **Package name:** `com.buildflow`
- **App name:** Studio App
- **Min SDK:** 21, **Target/Compile SDK:** 35

## Permissions

- `INTERNET` — call the GitHub API and download artifacts.
- `READ_EXTERNAL_STORAGE` (implicit via SAF) — pick your project zip.
- No full external-storage permission; APKs land in the app's private
  `StudioApp/` directory and are shared via a `FileProvider`.
